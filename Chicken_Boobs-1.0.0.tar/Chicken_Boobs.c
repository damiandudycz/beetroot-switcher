#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <curl/curl.h>
#include <json-c/json.h>
#include <math.h>  // Ensure math.h is included for fmax

#define IMAGE_ROWS 3
#define IMAGE_COLS 5
#define IMAGE_WIDTH 150
#define IMAGE_HEIGHT 150
#define WINDOW_PADDING 0
#define NUM_IMAGES (IMAGE_ROWS * IMAGE_COLS)
#define PEXELS_API_KEY "Dh0wryhMnjpLPcqEtZ7UqmKfYFc7A03IaFbArI6Fq9KwxamO9gQF94R3" // Replace with your actual Pexels API key

// Structure to store image data
typedef struct {
    int index;
    char filename[50];
    GtkWidget *image_widget;
    char **image_urls;
} ImageData;

// Structure for managing the curl download
typedef struct {
    char *memory;
    size_t size;
} MemoryStruct;

// Function to handle the curl response
size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t realsize = size * nmemb;
    MemoryStruct *mem = (MemoryStruct *)userp;

    char *ptr = realloc(mem->memory, mem->size + realsize + 1);
    if (!ptr) {
        printf("Not enough memory to allocate!\n");
        return 0;
    }

    mem->memory = ptr;
    memcpy(&(mem->memory[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;

    return realsize;
}

// Fetch image URLs from Pexels API
char **fetch_image_urls(int *num_images) {
    CURL *curl;
    CURLcode res;
    MemoryStruct chunk;
    chunk.memory = malloc(1);
    chunk.size = 0;

    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();

    // Pexels API request URL
    const char *url = "https://api.pexels.com/v1/search?query=chicken+breast+dish&per_page=15";
    
    // Set the necessary curl options
    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, NULL); // Add authorization header here if needed

    // Add the API key as a header
    struct curl_slist *headers = NULL;
    char auth_header[256];
    snprintf(auth_header, sizeof(auth_header), "Authorization: %s", PEXELS_API_KEY);
    headers = curl_slist_append(headers, auth_header);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

    // Perform the request
    res = curl_easy_perform(curl);

    // Check for errors
    if (res != CURLE_OK) {
        fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
        return NULL;
    }

    // Parse the JSON response to get image URLs
    json_object *parsed_json = json_tokener_parse(chunk.memory);
    json_object *photos;
    json_object_object_get_ex(parsed_json, "photos", &photos);

    int n_images = json_object_array_length(photos);
    *num_images = n_images;
    
    // Allocate memory for URLs
    char **image_urls = malloc(n_images * sizeof(char *));
    
    for (int i = 0; i < n_images; i++) {
        json_object *photo = json_object_array_get_idx(photos, i);
        json_object *src = json_object_object_get(photo, "src");
        json_object *url = json_object_object_get(src, "original");
        image_urls[i] = strdup(json_object_get_string(url));
    }

    curl_easy_cleanup(curl);
    free(chunk.memory);
    curl_global_cleanup();

    return image_urls;
}

// Function to randomize the image order
void shuffle_array(char **array, int n) {
    for (int i = n - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        char *temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}

// Function to update image in the UI
gboolean update_image_ui(gpointer data) {
    ImageData *img_data = (ImageData *)data;
    GdkPixbuf *pixbuf = gdk_pixbuf_new_from_file_at_scale(img_data->filename, IMAGE_WIDTH, IMAGE_HEIGHT, TRUE, NULL);
    if (pixbuf) {
        // Scale the pixbuf to fit the area with aspect fill and crop the edges
        int img_width = gdk_pixbuf_get_width(pixbuf);
        int img_height = gdk_pixbuf_get_height(pixbuf);

        // Calculate the scaling factor to fill the area
        float scale_x = (float)IMAGE_WIDTH / img_width;
        float scale_y = (float)IMAGE_HEIGHT / img_height;
        float scale_factor = fmax(scale_x, scale_y);

        int new_width = img_width * scale_factor;
        int new_height = img_height * scale_factor;

        // Scale the image to fill the target size, keeping the aspect ratio
        GdkPixbuf *scaled_pixbuf = gdk_pixbuf_scale_simple(pixbuf, new_width, new_height, GDK_INTERP_BILINEAR);
        if (scaled_pixbuf) {
            // Crop the image to fit the allocated size
            int x_offset = (new_width - IMAGE_WIDTH) / 2;
            int y_offset = (new_height - IMAGE_HEIGHT) / 2;

            GdkPixbuf *cropped_pixbuf = gdk_pixbuf_new_subpixbuf(scaled_pixbuf, x_offset, y_offset, IMAGE_WIDTH, IMAGE_HEIGHT);
            gtk_image_set_from_pixbuf(GTK_IMAGE(img_data->image_widget), cropped_pixbuf);
            g_object_unref(cropped_pixbuf);
            g_object_unref(scaled_pixbuf);
        }
        g_object_unref(pixbuf);
    }
    free(img_data);
    return FALSE;
}

// Function to download images asynchronously
void *download_image_thread(void *arg) {
    ImageData *img_data = (ImageData *)arg;
    snprintf(img_data->filename, sizeof(img_data->filename), "/tmp/image_%d.jpg", img_data->index);

    char command[512];
    snprintf(command, sizeof(command), "curl -s -o %s %s", img_data->filename, img_data->image_urls[img_data->index]);
    system(command);

    g_idle_add(update_image_ui, img_data);

    return NULL;
}

// Function to create placeholder image
GtkWidget *create_placeholder() {
    GtkWidget *image = gtk_image_new_from_icon_name("image-missing", GTK_ICON_SIZE_DIALOG);
    gtk_widget_set_size_request(image, IMAGE_WIDTH, IMAGE_HEIGHT);
    return image;
}

// GTK App Activation
void activate(GtkApplication *app, gpointer user_data) {
    GtkWidget *window = gtk_application_window_new(app);
    gtk_window_set_title(GTK_WINDOW(window), "Chicken Boobs");

    int window_width = IMAGE_COLS * IMAGE_WIDTH + WINDOW_PADDING;
    int window_height = IMAGE_ROWS * IMAGE_HEIGHT + WINDOW_PADDING;
    gtk_window_set_default_size(GTK_WINDOW(window), window_width, window_height);

    GtkWidget *grid = gtk_grid_new();
    gtk_container_add(GTK_CONTAINER(window), grid);

    // Fetch and randomize image URLs
    int num_images;
    char **image_urls = fetch_image_urls(&num_images);
    if (!image_urls) {
        printf("Failed to fetch image URLs\n");
        return;
    }

    shuffle_array(image_urls, num_images);

    for (int i = 0; i < NUM_IMAGES; i++) {
        ImageData *img_data = malloc(sizeof(ImageData));
        img_data->index = i % num_images;  // Wrap around if less than NUM_IMAGES
        img_data->image_urls = image_urls; // Pass the image URLs to the thread
        img_data->image_widget = create_placeholder();
        gtk_grid_attach(GTK_GRID(grid), img_data->image_widget, i % IMAGE_COLS, i / IMAGE_COLS, 1, 1);

        g_thread_new(NULL, (GThreadFunc)download_image_thread, img_data);
    }

    gtk_widget_show_all(window);
}

// Main function
int main(int argc, char **argv) {
    srand(time(NULL));  // Seed the random number generator

    GtkApplication *app = gtk_application_new("com.example.ChickenBoobs", G_APPLICATION_DEFAULT_FLAGS);
    g_signal_connect(app, "activate", G_CALLBACK(activate), NULL);
    int status = g_application_run(G_APPLICATION(app), argc, argv);
    g_object_unref(app);
    return status;
}

