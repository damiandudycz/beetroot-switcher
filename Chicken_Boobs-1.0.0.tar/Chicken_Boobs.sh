#!/bin/bash
gcc -o Chicken_Boobs Chicken_Boobs.c `pkg-config --cflags --libs gtk+-3.0` -lcurl -ljson-c -lpthread -lm
./Chicken_Boobs
